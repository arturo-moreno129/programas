<?php
session_start();
if (isset($_SESSION['nombre'])) {
    // Ya está logueado, redirigir al dashboard
    header('Location: main.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles_login.css">
    <title>Login</title>
</head>

<body>
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <form class="formulario" action="layouts/sesion.php" method="post" name="confir">
            <input type="text" name="user" placeholder="user" required>
            <div class="password-container">
                <input type="password" name="password" placeholder="Contraseña" id="password" required>
                <span class="toggle-password" onclick="togglePassword()">👁️</span>
            </div>
            <button type="submit">Entrar</button>
        </form>
        <a href="#">¿Olvidaste tu contraseña?</a>
        <a href="#">Registrarse</a>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
        }
    </script>
</body>

</html>