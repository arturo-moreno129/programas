<?php
require __DIR__ . '/vendor/autoload.php';

// Ruta absoluta al archivo de credenciales
putenv('GOOGLE_APPLICATION_CREDENTIALS=' . __DIR__ . '/credentials.json');

$client = new Google_Client();
$client->useApplicationDefaultCredentials();
$client->setScopes(['https://www.googleapis.com/auth/spreadsheets']);

$service = new Google_Service_Sheets($client);

// ID de tu hoja de Google
$spreadsheetId = "1NhEmgYUhdznhpJ6cC7dXmMFwLsYqHRMTotj3_2bBcLM";

// Nombre exacto de la hoja
$sheetName = "impresiones";

// Valores que quieres insertar
$codigo = 1813;
$nombre = "JMORENO";
$valorC = 0;
$valorD = 20;
$zona = "CENTRAL";
$mes = "julio";
$departamento = "Sistemas";
$fullName = "José Arturo Moreno Aguilar";
$anio = 2025;
$ciudad = "PUEBLA";

// Calculamos el valor de la fórmula en PHP
$formulaValue = $valorC + $valorD * 0.2;

// Creamos el array de valores a insertar
$values = [
    [
        $codigo,
        $nombre,
        $valorC,
        $valorD,
        $zona,
        $mes,
        $departamento,
        $fullName,
        $formulaValue, // valor calculado
        $anio,
        $ciudad
    ]
];

$body = new Google_Service_Sheets_ValueRange([
    'values' => $values
]);

$params = [
    'valueInputOption' => 'RAW' // ya enviamos el valor calculado, no fórmula
];

try {
    $result = $service->spreadsheets_values->append(
        $spreadsheetId,
        $sheetName,
        $body,
        $params
    );

    echo "Se insertaron " . $result->getUpdates()->getUpdatedCells() . " celdas.";
} catch (Exception $e) {
    echo "Error al insertar en Google Sheets: " . $e->getMessage();
}
