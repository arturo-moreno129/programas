<?php
include '../conexion.php';
$password = "Benito290496$"; //$_POST['password'];
// Hasheamos la contraseña con un algoritmo seguro (por defecto, PASSWORD_BCRYPT)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$query = "INSERT into usuarios values(default,'JMoreno','Jose Arturo','Moreno','Aguilar','Soporte','$hashed_password',1)";
/*$query_impresora = "INSERT into impresoras values (default,'TORRE DE CONTROL','BROTHER','140.240.13.203','B4:22:00:79:4B:1C','$hashed_password'),
                                                    (default,'VENTAS AFUERA','BROTHER','140.240.13.204','84:25:19:67:2F:F4','$hashed_password'),
                                                    (default,'RECURSOS HUMANOS','KYOCERA','140.240.13.207','00:17:C8:CB:0D:2F','$hashed_password'),
                                                    (default,'CONTABILIDAD','KYOCERA','140.240.13.219','00:17:C8:CA:FE:46','$hashed_password'),
                                                    (default,'RECEPCIÓN','KYOCERA','140.240.13.205','00:17:C8:EA:03:37','$hashed_password'),
                                                    (default,'ALMACÉN','KYOCERA','140.240.13.120','00:17:C8:CA:FE:37','$hashed_password')";*/
echo mysqli_query($con, $query);
//$query= "UPDATE usuario SET contrasena = '$hashed_password' WHERE id_usuario > 1";
//mysqli_query($con, $query);
?>
