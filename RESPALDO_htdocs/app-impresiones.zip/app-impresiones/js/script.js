const cloud = document.getElementById("cloud");
const barraLateral = document.querySelector(".barra-lateral");
const spans = document.querySelectorAll("span");
const palanca = document.querySelector(".switch"); //--------
const circulo = document.querySelector(".circulo"); //--------
const menu = document.querySelector(".menu");
const main = document.querySelector("main");

const btn = document.querySelector(".push");

const modoOscuroGuardado = localStorage.getItem("darkMode");
const cuerpo = document.body;

if (modoOscuroGuardado === "activado") {
  cuerpo.classList.add("dark-mode");
  circulo.classList.toggle("prendido");
}

menu.addEventListener("click", () => {
  barraLateral.classList.toggle("max-barra-lateral");
  if (barraLateral.classList.contains("max-barra-lateral")) {
    menu.children[0].style.display = "none";
    menu.children[1].style.display = "block";
  } else {
    menu.children[0].style.display = "block";
    menu.children[1].style.display = "none";
  }
  if (window.innerWidth <= 320) {
    barraLateral.classList.add("mini-barra-lateral");
    main.classList.add("min-main");
    spans.forEach((span) => {
      span.classList.add("oculto");
    });
  }
});

palanca.addEventListener("click", () => {
  let body = document.body;
  body.classList.toggle("dark-mode");
  circulo.classList.toggle("prendido");
  if (cuerpo.classList.contains("dark-mode")) {
    localStorage.setItem("darkMode", "activado");
  } else {
    localStorage.setItem("darkMode", "desactivado");
  }
});
